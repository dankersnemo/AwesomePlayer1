package com.example.awesomeplayer;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.BreakIterator;
import java.util.HashMap;
import java.util.List;


public class SongPlay extends Activity implements AudioManager.OnAudioFocusChangeListener {
    HashMap<String, String> SongD;
    ContentResolver contentResolver;
    Cursor cursor;
    Uri uri;
    TextView txtSongTitle,txtSongArtist;
    private TextView txtTimestamp;
    Handler mHandler;
    ImageView imgAlbumArt, btnPlayPause;
    MediaPlayer mPlayer;
    SeekBar mSeekBar;
    private Runnable mRunnable;
    AudioManager mAudioManager;
    String SongTitle, SongArtist, str ;
    DataBaseHelper db;
    private Object ImageView;
    SongList songList = new SongList();
    byte[] art;
    ImageView album_art;
    MediaMetadataRetriever metaRetriver;
    public String thePath;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_play);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //getArt("/storage/extSdCard/Test.mp3");

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Intent Dintent = getIntent();
        List<String> SongPath= (List)Dintent.getSerializableExtra("key2");

        //List<String> SongPath= (List)Dintent.getSerializableExtra("key2");
        //Toast.makeText(getApplicationContext(),thePath,Toast.LENGTH_LONG).show();
        //songList.getSongFromInt(0);












        if (Intent.ACTION_VIEW.equals(getIntent().getAction()))
        {
            str = (getIntent().getData().getPath());
        }else {
            Bundle extras = getIntent().getExtras();
            str = extras.getString("SongData");
        }
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        txtSongTitle = findViewById(R.id.txtSongTitle);
        txtSongArtist = findViewById(R.id.txtSongArtist);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        txtTimestamp = findViewById(R.id.txtTimestamp);
        mSeekBar = findViewById(R.id.seekBar);
        imgAlbumArt = findViewById(R.id.imgAlbumArt);
        mHandler = new Handler();
        mPlayer = new MediaPlayer();
        db = new DataBaseHelper(this);
        contentResolver = SongPlay.this.getContentResolver();

        uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] STAR={"*"};
        cursor = contentResolver.query(
                uri,
                STAR,
                selection,
                null,
                null
        );
        //cursor.move(8);
        if (cursor == null) {
            Toast.makeText(SongPlay.this, "Something Went Wrong.", Toast.LENGTH_SHORT);
        } else if (!cursor.moveToFirst()) {
            Toast.makeText(SongPlay.this, "No Music Found on SD Card.", Toast.LENGTH_SHORT);
        } else {
            int Title = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int Data = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int Artist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int ID = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
            int Duration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int AlbumId = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID);
            do {
                String SongData = cursor.getString(Data);
                if(SongData.equals(str))//////need to edit this///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                {
                    SongTitle = cursor.getString(Title);
                    SongArtist = cursor.getString(Artist);
                    int SongDuration = Integer.parseInt(cursor.getString(Duration));
                    //long SongAlbumID = Long.parseLong(cursor.getString(AlbumId));
                    SongDuration=SongDuration/1000;
                    txtTimestamp.setText("0:0 | "+Integer.toString(SongDuration/60)+":"+Integer.toString(SongDuration%60));
                    Uri sArtworkUri = Uri.parse("content://media/external/audio/albumart");
                    //Uri albumArtUri = ContentUris.withAppendedId(sArtworkUri, SongAlbumID);
                    Bitmap bitmap= BitmapFactory.decodeResource(getResources(), R.drawable.newpic);
                    //Toast.makeText(getApplicationContext(),String.valueOf(SongD),Toast.LENGTH_SHORT).show();


                    metaRetriver = new MediaMetadataRetriever();
                    String thePath = (String) Dintent.getSerializableExtra("key3");
                    String old = "/storage/extSdCard/MUSIC/Test.mp3";

                    try {
                        metaRetriver.setDataSource(thePath);


                        art = metaRetriver.getEmbeddedPicture();
                        Bitmap songImage = BitmapFactory.decodeByteArray(art, 0, art.length);
                        imgAlbumArt.setImageBitmap(songImage);

                    }catch (Exception e){
                        //metaRetriver.setDataSource(thePath);


                        art = metaRetriver.getEmbeddedPicture();
                        bitmap= BitmapFactory.decodeResource(getResources(), R.drawable.newpic);

                        imgAlbumArt.setImageBitmap(bitmap);

                    }

                    metaRetriver.setDataSource(old);


                    art = metaRetriver.getEmbeddedPicture();
                    Bitmap songImage = BitmapFactory.decodeByteArray(art, 0, art.length);
                    //imgAlbumArt.setImageBitmap(songImage);
                    //setArt();


                    Toast.makeText(getApplicationContext(),thePath,Toast.LENGTH_SHORT).show();





                   try {
                        //bitmap = MediaStore.Images.Media.getBitmap(SongPlay.this.getContentResolver(), albumArtUri);

                       art = metaRetriver.getEmbeddedPicture();



                       //album_art.setImageBitmap(songImage);



                    }catch(Exception e){}
                    txtSongTitle.setText(SongTitle);
                    txtSongArtist.setText(SongArtist);








                   //Toast.makeText(getApplicationContext(),String.valueOf(SongD),Toast.LENGTH_SHORT).show();

                    break;

                }
            } while (cursor.moveToNext());

        }
        try{
            mPlayer.setDataSource(str);
            mPlayer.prepareAsync();
            mPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                    mPlayer.seekTo(db.ReadPos(str));
                    int duration  = mPlayer.getDuration()/1000; // In milliseconds
                    int pass =  mPlayer.getCurrentPosition()/1000;
                    txtTimestamp.setText(Integer.toString(pass/60)+":"+Integer.toString(pass%60)+" | "+Integer.toString(duration/60)+":"+Integer.toString(duration%60));
                    mSeekBar.setMax(mPlayer.getDuration());
                    SongPlay.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(mPlayer != null){
                                int mcurpos=mPlayer.getCurrentPosition();
                                mSeekBar.setProgress(mcurpos);
                                int duration  = mPlayer.getDuration()/1000; // In milliseconds
                                int pass =  mPlayer.getCurrentPosition()/1000;
                                txtTimestamp.setText(Integer.toString(pass/60)+":"+Integer.toString(pass%60)+" | "+Integer.toString(duration/60)+":"+Integer.toString(duration%60));
                            }
                            mHandler.postDelayed(this, 1);

                        }
                    });
                }
            });
        }catch (Exception e){
            try{
                mPlayer.start();
            }catch (Exception a){}
        }
        btnPlayPause.setImageResource(R.drawable.pauseim);

        btnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mPlayer.isPlaying())
                {
                    btnPlayPause.setImageResource(R.drawable.playim);
                    mPlayer.pause();
                }else
                {
                    mPlayer.start();
                    btnPlayPause.setImageResource(R.drawable.pauseim);
                }
            }
        });

        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mPlayer != null && fromUser){
                    mPlayer.seekTo(progress);
                }
            }
        });
    }

    @Override
    public void onAudioFocusChange(int focusState) {
        switch (focusState) {
            case AudioManager.AUDIOFOCUS_GAIN:
                // resume playback
                mPlayer.start();
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                // Lost focus for an unbounded amount of time: stop playback and release media player
                if (mPlayer.isPlaying()) mPlayer.pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // Lost focus for a short time, but we have to stop
                // playback. We don't release the media player because playback
                // is likely to resume
                if (mPlayer.isPlaying()) mPlayer.pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // Lost focus for a short time, but it's ok to keep playing
                // at an attenuated level
                if (mPlayer.isPlaying()) mPlayer.setVolume(0.1f, 0.1f);
                break;
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if(mPlayer.isPlaying()) {
            if(mPlayer!=null){
                mPlayer.stop();
                mPlayer.release();
                mPlayer = null;
                if(mHandler!=null){
                    mHandler.removeCallbacks(mRunnable);
                }
            }
        }
        mAudioManager.abandonAudioFocus(this);
    }




    public void getArt(String file ){
        ImageView image = (ImageView) findViewById(R.id.imgAlbumArt);



        MediaMetadataRetriever metaRetriver;
        byte[] art;
        ImageView album_art ;
        album_art = (ImageView) findViewById(R.id.imgAlbumArt);
        album_art.setBackgroundColor(Color.GRAY);



        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        String url = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
        cursor.close();

        String sdpath = null,sd1path,usbdiskpath,sd0path;

        if(new File("/storage/extSdCard/").exists())
        {
            sdpath="/storage/extSdCard/";
            Log.i("Sd Cardext Path",sdpath);
        }
        if(new File("/storage/sdcard1/").exists())
        {
            sd1path="/storage/sdcard1/";
            Log.i("Sd Card1 Path",sd1path);
        }
        if(new File("/storage/usbcard1/").exists())
        {
            usbdiskpath="/storage/usbcard1/";
            Log.i("USB Path",usbdiskpath);
        }
        if(new File("/storage/sdcard0/").exists())
        {
            sd0path="/storage/sdcard0/";
            Log.i("Sd Card0 Path",sd0path);
        }
        //Toast.makeText(getApplicationContext(),sdpath, Toast.LENGTH_LONG).show();
        metaRetriver = new MediaMetadataRetriever();
        metaRetriver.setDataSource(sdpath+"Test.mp3");

        try {

            BreakIterator album = null;
            album.setText(metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            

            art = metaRetriver.getEmbeddedPicture();

            Bitmap songImage = BitmapFactory.decodeByteArray(art, 0, art.length);

            album_art.setImageBitmap(songImage);





        } catch (Exception e) {
            album_art.setBackgroundColor(Color.GREEN);

        }

    }








    }



