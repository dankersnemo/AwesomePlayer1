# AndroidSongMetaDataUpdate
Update ID3 Meta data of audio files 
Reference: 
ID3 Library: https://sites.google.com/site/eternalsandbox/myid3-for-android 
More information: https://stackoverflow.com/questions/9707572/how-to-get-and-set-change-id3-tag-metadata-of-audio-files
