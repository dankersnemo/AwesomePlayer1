package com.example.awesomeplayer;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SongList extends AppCompatActivity implements Serializable {

    Context context;
    String[] ListElements = new String[]{};
    ListView listView;
    public List<String> ListElementsArrayList;
    public List<String> SongPath;
    ArrayAdapter<String> adapter;
    ContentResolver contentResolver;
    Cursor cursor;
    Uri uri;
    public static final int RUNTIME_PERMISSION_CODE = 7;
    HashMap<String, String> SongD;
    DataBaseHelper db;
    float temperaturebms;
    ListView canSee;
    int LastPos = 0;
    public String thePath = "test";


    Intent Dintent;

    MediaMetadataRetriever metaRetriver;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_list);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        SongD = new HashMap<>();
        listView = findViewById(R.id.listView);


















        context = getApplicationContext();
        ListElementsArrayList = new ArrayList<>(Arrays.asList(ListElements));
        SongPath = new ArrayList<>(Arrays.asList(ListElements));
        Collections.sort(ListElementsArrayList);
        Collections.sort(SongPath);
        adapter = new ArrayAdapter<>
                (SongList.this, android.R.layout.simple_list_item_checked, ListElementsArrayList);

        AndroidRuntimePermission();
        GetAllMediaMp3Files();
        listView.setAdapter(adapter);
        db = new DataBaseHelper(this);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tempo = db.cEntry(SongD.get(parent.getAdapter().getItem(position).toString()),temperaturebms);
                if(SongD.get(parent.getAdapter().getItem(position).toString()).equals(db.cEntry(SongD.get(parent.getAdapter().getItem(position).toString()),temperaturebms)))
                {
                    db.EntryUpdate(SongD.get(parent.getAdapter().getItem(position).toString()),temperaturebms);
                }else
                {
                    db.SongEntry(SongD.get(parent.getAdapter().getItem(position).toString()),parent.getAdapter().getItem(position).toString(),temperaturebms);
                }
                String SongMessage = SongD.get(parent.getAdapter().getItem(position).toString());
                Intent intent = new Intent(SongList.this, SongPlay.class);
                intent.putExtra("SongData", SongMessage);

                Object theData = myData(ListElementsArrayList);
                Object theData2 = myData(SongPath);
                Object theData3 = myDataString(thePath);
                intent.putExtra("key2", (Serializable) theData);


                //intent.putExtra("key2", (Serializable) theData2);



                SongPath.add(SongMessage);
                String teep =
                        SongD.get(parent.getAdapter().getItem(position));
                Toast.makeText(getApplicationContext(),teep,Toast.LENGTH_SHORT).show();
                thePath = teep;

                intent.putExtra("key3",  thePath);

                startActivity(intent);
                LastPos=(listView.getFirstVisiblePosition());
                View see = listView.getChildAt(LastPos);
                listView.getId();





                //Toast.makeText(getApplicationContext(),String.valueOf(getSongFromInt(LastPos)+" "+LastPos),Toast.LENGTH_SHORT).show();








            }
        });

    }
    public void GetAllMediaMp3Files() {
        contentResolver = context.getContentResolver();
        uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] STAR={"*"};
        cursor = contentResolver.query(
                uri,
                STAR,
                selection,
                null,
                null
        );
        if (cursor == null ) {
            Toast.makeText(SongList.this, "Something Went Wrong.", Toast.LENGTH_SHORT).show();
        } else if (!cursor.moveToFirst()) {
            Toast.makeText(SongList.this, "No Music Found on SD Card.", Toast.LENGTH_SHORT).show();
        } else {
            int Title = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int Data = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);


            do if (true){


                //startActivity(intent);







                String SongTitle = cursor.getString(Title);
                String SongData = cursor.getString(Data);
                ListElementsArrayList.add(SongTitle);
                SongD.put(SongTitle , SongData);
                //SongPath.add(SongTitle);
            } while (cursor.moveToNext());

        }

        //list data to SongPlay

        //startActivity(intent);

       // startActivity(intent);



    }
    public void AndroidRuntimePermission(){

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){

            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
                if(shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)){
                    AlertDialog.Builder alert_builder = new AlertDialog.Builder(SongList.this);
                    alert_builder.setMessage("External Storage Permission is Required.");
                    alert_builder.setTitle("Please Grant Permission.");
                    alert_builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCompat.requestPermissions(
                                    SongList.this,
                                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                    RUNTIME_PERMISSION_CODE
                            );
                        }
                    });
                    alert_builder.setNeutralButton("Cancel",null);
                    AlertDialog dialog = alert_builder.create();
                    dialog.show();
                }
                else {
                    ActivityCompat.requestPermissions(
                            SongList.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            RUNTIME_PERMISSION_CODE
                    );
                }
            }else {
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case RUNTIME_PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                } else {
                }
            }
        }
    }

     int getSongNameL(String n) {
        int num = -1;
        int Snum = 0;

         for (String temp : ListElementsArrayList) {
             num++;
             if(temp.equals(n)){
                 Snum = num;

             }
         }








        return Snum;
    }
    public String getSongFromInt(int num){
        String name = ListElementsArrayList.get(num);



        return name;
    }
    public List myData(List data){
        List<String> tepListElementsArrayList = data;



        return tepListElementsArrayList;
    }
    public String myDataString(String data){
        String tep = data;



        return tep;
    }

    public HashMap myDataHash(HashMap data){
        HashMap<String, String> SongD = data;



        return data;
    }
    public String getSongPath(String name){
        String path = SongD.get(name);




        return path;
    }






}
