package com.example.mp3test2;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

// put mp3 in root sd card name Test.mp3
// mp3 must have tags of it will show up blank

public class MainActivity extends AppCompatActivity {





    MediaMetadataRetriever metaRetriver;
    byte[] art;
    ImageView album_art;
    TextView album, artist, genre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getInit();

        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;


        Cursor cursor = getContentResolver().query(uri, null, null, null, null);


        cursor.moveToFirst();

        String url = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));


        cursor.close();

        // find sd path/////////////////////////////////////////////////

        String sdpath = null,sd1path,usbdiskpath,sd0path;

        if(new File("/storage/extSdCard/").exists())
        {
            sdpath="/storage/extSdCard/";
            Log.i("Sd Cardext Path",sdpath);
        }
        if(new File("/storage/sdcard1/").exists())
        {
            sd1path="/storage/sdcard1/";
            Log.i("Sd Card1 Path",sd1path);
        }
        if(new File("/storage/usbcard1/").exists())
        {
            usbdiskpath="/storage/usbcard1/";
            Log.i("USB Path",usbdiskpath);
        }
        if(new File("/storage/sdcard0/").exists())
        {
            sd0path="/storage/sdcard0/";
            Log.i("Sd Card0 Path",sd0path);
        }
        Toast.makeText(getApplicationContext(),sdpath, Toast.LENGTH_LONG).show();
        metaRetriver = new MediaMetadataRetriever();
        metaRetriver.setDataSource(sdpath+"Test.mp3");
/////////////////////////////////////////////////////////////////////////////////
        try {
            art = metaRetriver.getEmbeddedPicture();

            Bitmap songImage = BitmapFactory.decodeByteArray(art, 0, art.length);

            album_art.setImageBitmap(songImage);

            album.setText(metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            artist.setText(metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            genre.setText(metaRetriver
                    .extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));




        } catch (Exception e) {
            album_art.setBackgroundColor(Color.GRAY);

        }
    }

    public void getInit() {

        album_art = (ImageView) findViewById(R.id.album_art);
        album = (TextView) findViewById(R.id.Album);
        artist = (TextView) findViewById(R.id.artist_name);
        genre = (TextView) findViewById(R.id.genre);

    }

}