package com.example.coolsplash;

public class Splash {
}
